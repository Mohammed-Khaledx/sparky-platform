# Team Collaborators

This file outlines the team members and their roles in the project.

---

## Team Leader

- **Name:** Mohammed Khaled Noby  
- **GitHub:** github.com/Mohammed-Khaledx  
- **Email:** mohammedkhaledx1@gmail.com  
 
---

## Core Team Members

The following members contributed to specific areas of the project:

1. **Mohammed Salah**  
   - **GitHub:** github.com/med260  
   - **Email:** medos80268026@gmail.com  
   <!-- - **Role:**    -->
   <!-- - **Responsibilities:**  -->

2. **[Member Name 2]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

3. **[Member Name 3]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

4. **[Member Name 4]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

5. **[Member Name 5]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

6. **[Member Name 6]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

7. **[Member Name 7]**  
   - **GitHub:** [GitHub Username]  
   - **Email:** [Email Address]  
   <!-- - **Role:**  -->
   <!-- - **Responsibilities:** -->

---
