export interface Follows {
  _id: string;
  follower: string;
  following: string;
  createdAt: string;
  updatedAt: string;
}
